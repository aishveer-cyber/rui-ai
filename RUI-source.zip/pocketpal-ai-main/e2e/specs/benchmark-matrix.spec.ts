/**
 * Benchmark Matrix E2E Spec (v2 — BenchmarkRunnerScreen-driven).
 *
 * Drives the in-app BenchmarkRunnerScreen across {models} x {quants} x
 * {backends}. The screen owns the matrix loop, downloads, init/release,
 * peak-memory tracking, and JSON writing. This spec just pushes a config,
 * deep-links the screen with `?autostart=1` (which self-starts the run, no
 * tap), polls status, and pulls the JSON.
 *
 *   yarn e2e --platform android --spec benchmark-matrix --skip-build
 *   BENCH_MODELS=qwen3-1.7b BENCH_QUANTS=q4_0 BENCH_BACKENDS=gpu yarn e2e ...
 *   BENCH_MAX_WAIT_MIN=120 yarn e2e ...        # default 60 min
 *
 * Android-only in v1.
 */

import * as fs from 'fs';
import * as path from 'path';

import {getBenchmarkMatrix} from '../fixtures/benchmark-models';
import {byTestId} from '../helpers/selectors';
import {OUTPUT_DIR} from '../wdio.shared.conf';
import {
  assertRowsPass,
  deepLinkLaunch,
  pullLatestReport,
  pushConfig,
  stampReportMetadata,
} from '../helpers/bench-runner';

declare const driver: WebdriverIO.Browser;
declare const browser: WebdriverIO.Browser;

const MAX_WAIT_MS =
  parseInt(process.env.BENCH_MAX_WAIT_MIN || '60', 10) * 60_000;
const POLL_MS = 5000;

describe('Benchmark Matrix', function () {
  this.timeout(
    Math.max(Number(process.env.E2E_MOCHA_TIMEOUT) || 0, MAX_WAIT_MS + 60_000),
  );

  const matrix = getBenchmarkMatrix();
  const udid = process.env.E2E_DEVICE_UDID;
  let outDir: string;

  before(async () => {
    if (!(driver as any).isAndroid) throw new Error('Android-only.');
    if (
      !matrix.models.length ||
      !matrix.quants.length ||
      !matrix.backends.length
    ) {
      throw new Error('BENCH_* filters excluded every cell.');
    }
    outDir = path.join(OUTPUT_DIR, 'benchmarks');
    fs.mkdirSync(outDir, {recursive: true});
    pushConfig(matrix, udid);
    await deepLinkLaunch();
  });

  it('runs the matrix and writes a JSON report', async () => {
    // No tap: the deep link carried `?autostart=1`, so the screen self-starts
    // the matrix once it mounts (the fix for HyperOS / MediaTek dropping
    // injected taps). We just wait for the status element to appear, then
    // poll it for a terminal state — no `bench-run-button` interaction.
    const status = await driver.$(byTestId('bench-runner-screen-status'));
    await status.waitForDisplayed({timeout: 30_000});

    const readStatus = async (): Promise<string | null> =>
      (await status.getAttribute('content-desc').catch(() => null)) ??
      (await status.getText().catch(() => null));

    // Fast-fail diagnostic: with autostart=1 the screen must leave `idle`
    // within seconds of mount. If it doesn't, the autostart param never
    // reached the screen — fail in 30s with that specific signal instead
    // of burning the full BENCH_MAX_WAIT_MIN on a silent timeout.
    let lastObserved: string | null = await readStatus();
    try {
      await browser.waitUntil(
        async () => {
          lastObserved = await readStatus();
          return typeof lastObserved === 'string' && lastObserved !== 'idle';
        },
        {timeout: 30_000, interval: 1_000},
      );
    } catch {
      // Rethrow with the actual last-observed status interpolated. (WDIO's
      // own timeoutMsg is a static string built before the wait starts, so
      // it cannot include the value of `lastObserved` at timeout time.)
      throw new Error(
        `autostart did not leave 'idle' within 30s (last status=${lastObserved ?? 'null'}). The screen mounted but the autostart deep-link param never triggered onRun — likely a regression in the deep-link param plumbing or the screen's once-per-mount effect.`,
      );
    }

    const deadline = Date.now() + MAX_WAIT_MS;
    let terminal: string | null = null;
    while (Date.now() < deadline) {
      await browser.pause(POLL_MS);
      const s = await readStatus();
      if (typeof s === 'string') {
        lastObserved = s;
      }
      if (s === 'complete' || (typeof s === 'string' && s.startsWith('error:'))) {
        terminal = s;
        break;
      }
    }
    if (!terminal) {
      throw new Error(
        `No terminal state within ${MAX_WAIT_MS / 60_000} min (last status=${lastObserved ?? 'null'}).`,
      );
    }

    const localFile = pullLatestReport(outDir, udid);
    const report = JSON.parse(fs.readFileSync(localFile, 'utf8'));

    // The screen writes the per-cell payload (incl. log_signals and
    // effective_backend, derived in-process via addNativeLogListener); the
    // spec fills the top-level device/soc/commit/llama_rn/os fields the
    // screen has no clean way to know.
    const caps = (driver.capabilities || {}) as Record<string, any>;
    stampReportMetadata(report, {
      device: caps.deviceModel || process.env.E2E_DEVICE_NAME || 'unknown',
      osVersion:
        caps.platformVersion || process.env.E2E_PLATFORM_VERSION || 'unknown',
    });
    fs.writeFileSync(localFile, JSON.stringify(report, null, 2));

    if (terminal !== 'complete') throw new Error(`Matrix ended: ${terminal}`);
    assertRowsPass(report);
    console.log(`Matrix complete: ${report.runs.length} rows in ${localFile}`);
  });
});
